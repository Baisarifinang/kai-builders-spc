KAI BUILDERS SPC — DOMAIN-STYLE CORPORATE WEBSITE
=================================================

Files:
- index.html       Main responsive homepage
- styles.css       Premium navy / gold corporate styling
- script.js        Mobile navigation + dynamic year
- assets/          Logos, mineral/construction images, company profile PDF

FREE HOSTING
------------
This is a static website. It can be hosted free on GitHub Pages, Cloudflare Pages,
Netlify, or another static host.

CUSTOM DOMAIN
-------------
If KAI BUILDERS SPC later uses a custom domain (for example, kaibuildersspc.com),
connect the domain through the hosting provider's DNS settings. Domain registration
is normally a separate annual cost.

CONTACT DETAILS USED
--------------------
Email: kaibuilders.spc@gmail.com
Telephone: +63 2 8790 4327
Mobile / WhatsApp: 0953 283 8004 / 0947 478 8636
Office: 5/F Gateway Tower, Gen. Roxas Ave. cor. Gen. Aguinaldo Ave., Araneta Center,
Cubao, Quezon City, Philippines

IMPORTANT
---------
Before publishing externally, confirm all corporate registration details, permits,
project references, mining claims, assay statements, addresses, phone numbers and
other commercial information against current official records.
